<p align="center">
    <img align="center" width="300" src="https://github.com/user-attachments/assets/d31fab0f-4d7e-46e8-adae-ed9270cf0a26" />
    <h3 align="center"></h3>
</p>

<p align="center">
  <a href="https://pypi.org/project/PyiMAi/">
    <img src="https://img.shields.io/pypi/v/PyiMAi.svg?logo=python&logoColor=%23959DA5&label=pypi&labelColor=%23282f37">
  </a>
  
  <a href="https://t.me/PyCodz">
    <img src="https://img.shields.io/badge/Telegram-Channel-blue.svg?logo=telegram">
  </a>
    
  <a href="https://t.me/PyChTz" target="_blank">
    <img alt="Telegram-Discuss" src="https://img.shields.io/badge/Telegram-Discuss-blue.svg?logo=telegram" />
  </a>
</p>

<p align="center">

  <a href="https://pepy.tech/projects/PyiMAi/">
    <img src="https://static.pepy.tech/personalized-badge/PyiMAi?period=total&units=INTERNATIONAL_SYSTEM&left_color=BLACK&right_color=GREEN&left_text=downloads">
  </a>

  <a href="https://github.com/DevZ44d/PyiMAi?tab=MIT-1-ov-file">
    <img src="https://camo.githubusercontent.com/30aa09995ff273a3a2a8abf7c116c6fadfb4737b6aac74fe8dcb03e93d855fef/68747470733a2f2f696d672e736869656c64732e696f2f6769746875622f6c6963656e73652f7a3434642f79746d757369632d626f74">
  </a>
</p>


### PyMind 
> **_PyiMAi_** is a lightweight AI-powered CLI tool that allows you to interact with an AI model directly from your terminal, with optional image support.

### 🚀 Features
- 💬 Chat with AI from your terminal
- 🖼️ Send images along with prompts
- ☁️ Upload images and get public URLs
- ⚡ Simple CLI interface
- 🧠 Works with or without images
- 📦 Ready to use as a Python library or CLI tool

### 📦 Installation

- Clone the project:
```shell
git clone https://github.com/DevZ44d/PyiMAi.git
```

- Via PyPi
```shell
pip install pyimai -U
```
### 🧠 Usage Example (_Class Ai_)
- Chatting with _Artificial Intelligence_ (AI). I
```python
from pyimai import Ask
def main():
    prompt: Ask= Ask(
        prompt="Hello, what is this?", 
        filepath=["download.jpg"] #you can add multi photos (local)
    )

    print(prompt.chat())

if __name__ == "__main__":
    main()
```

- Uploading Image Online .

```python
from pyimai import Upload


def main():
    _: Upload = Upload(
        filepath=["download.jpg"],  # you can add multi photos (required)
        expiration=15552000,  # automatically deleted after a certain time (in seconds, 60-15552000). (optional)
        key=""  # i default added one, so delete this argument (optional)
    )

    print(_.get_info())


if __name__ == "__main__":
    main()
```

### Example response (_Class Ai_) (JSON)
```json
{
    "request": "Hello, what is this ? and solve it .",
    "response": "This is a Math Olympiad question asking to solve the equation:\n\na^3 + a^2 = 36\n\nWe need to find the value of a that satisfies this equation.\n\nLet's solve it step-by-step:\n\n1. Rewrite the equation:\na^3 + a^2 = 36\n\n2. Factor out a^2:\na^2(a + 1) = 36\n\n3. Now, we look for integer values of a that satisfy this equation because Math Olympiad problems often expect integer or simple rational solutions.\n\nTry a = 2:\n2^2 × (2 + 1) = 4 × 3 = 12 ≠ 36\n\nTry a = 3:\n3^2 × (3 + 1) = 9 × 4 = 36\n\nThis works perfectly.\n\nSo, a = 3 is a solution.\n\nAnswer:\na = 3"
}
```

---

### Example response (_Class Upload_) (JSON)
```json
[
    {
        "data": {
            "delete_url": "https://ibb.co/twK1wYrW/db713ad7cde63f41189c589710396be2",
            "display_url": "https://i.ibb.co/MySJyP03/download.jpg",
            "expiration": 15552000,
            "height": 168,
            "id": "twK1wYrW",
            "image": {
                "extension": "jpg",
                "filename": "download.jpg",
                "mime": "image/jpeg",
                "name": "download",
                "url": "https://i.ibb.co/MySJyP03/download.jpg"
            },
            "size": 7895,
            "thumb": {
                "extension": "jpg",
                "filename": "download.jpg",
                "mime": "image/jpeg",
                "name": "download",
                "url": "https://i.ibb.co/twK1wYrW/download.jpg"
            },
            "time": 1765918544,
            "title": "download",
            "url": "https://i.ibb.co/MySJyP03/download.jpg",
            "url_viewer": "https://ibb.co/twK1wYrW",
            "width": 299
        },
        "status": 200,
        "success": true
    }
]
```

### Class Terminal 🧠
```shell
pyimai -[OPTIONS] "[FOR-OPTION]"

Arguments:	           - Description:
    -p, --prompt	      Send a prompt to the AI
    -f, --filepath	      Image path (optional)
    -u, --upload	      Upload image only
    -e, --expiration	  Image expiration time (seconds)
    -k, --key             The API key.
    -v, --version	      Show version
    -h, --help	          Show help
```

### 🚀 Usage (_Class Terminal_)
- 🔹Send a normal text prompt (no image required):

```shell
pyimai -p "hello"
```

- 🔹Ask the AI about an image:
```shell
pyimai -p "what is this?" -f "photo.jpg" # image must be in directory
```

- 🔹 Upload an image and get its public URL:
```shell
pyimai -u "photo.jpg"
```

- 🔹 Show version:
```shell
pyimai -v
```
- 🔹 Show help:
```shell
pyimai -h
```

### 💬 Help & Support .
- Follow updates via the **[Telegram Channel](https://t.me/Pycodz)**.
- For general questions and help, join our **[Telegram chat](https://t.me/PyChTz)**.